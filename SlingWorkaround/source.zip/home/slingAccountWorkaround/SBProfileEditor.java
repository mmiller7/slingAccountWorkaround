//Matthew Miller
//August 10, 2010
//Last updated November 06, 2010
//SBProfileEditor.java
//SBProfile.xml editor
//Workaround to avoid using SlingAccount on SlingPlayer 2.0
//
//To use for an applet:
//change "extends JFrame" to "extends JApplet"
//and rename "static void main(...)" "void init()" 

package slingAccountWorkaround;
import javax.swing.*;

import classesByMatt.CommonTasks;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * @author Matthew Miller
 * SBProfile.xml editor
 * Workaround to avoid using SlingAccount on SlingPlayer 2.0
 */
@SuppressWarnings("serial")
public class SBProfileEditor extends JFrame implements ActionListener, WindowListener, Runnable
{
	//instantiate componants (JButton, JTextField, etc.)
	private JTextField pathToSBProfile = new JTextField(44);
	private JButton about = new JButton("Help/About");
	private JButton saveChanges = new JButton("Save Changes");
	private JButton newDevice = new JButton("New Device");
	private JPanel displayDevices = new JPanel();
	
	//Arrays to hold SlingBox objects and corrispondingeditor buttons
	private ArrayList<SlingBox> devices = new ArrayList<SlingBox>(10);
	private ArrayList<JButton> deleteDevice = new ArrayList<JButton>(10);
	private ArrayList<JButton> editDevice = new ArrayList<JButton>(10);
	
	//used to determine if there are unsaved changes before exit
	private boolean isSaved = true;
	
	//used to pass actions to new thread
	private ActionEvent lastAction;
	
	/**
	 * Creates main GUI for SBProfile editor
	 */
	public SBProfileEditor()
	{
		//find SBProfile
		setPathToSBProfile();
		//read existing entries;
		readSBProfile();
		
		//Create JPanel(s) and add componants to panels
		JPanel panel1 = new JPanel();
			panel1.add(new JLabel("SBProfile.xml:"));
			panel1.add(pathToSBProfile);
			pathToSBProfile.setEditable(false);
		JScrollPane jsp = new JScrollPane(displayDevices, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); //To enable scrolling
			displayDevices.setLayout(new BoxLayout(displayDevices, BoxLayout.PAGE_AXIS));
		JPanel panel2 = new JPanel();
			panel2.add(about);
			panel2.add(newDevice);
			panel2.add(saveChanges);
		
		//Add panels to container
		@SuppressWarnings("unused")
		Container container = getContentPane();
		
		container.add(panel1, BorderLayout.NORTH);
		container.add(jsp, BorderLayout.CENTER);
		container.add(panel2, BorderLayout.SOUTH);
		
		//Add action listeners
		about.addActionListener(this);
		newDevice.addActionListener(this);
		saveChanges.addActionListener(this);
		//to catch window closed event
		this.addWindowListener(this);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		SBProfileEditor frame = new SBProfileEditor();
		frame.setTitle("Editor for SBProfile.xml - Rev. 2010.11.06");
		frame.setSize(600,400);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		//store action event to be run in new thread
		lastAction=e;
		//create new thread to run action
		Thread t = new Thread(this);
		//start new thread and execute action
		t.start();
	}

	/**
	 * Sets pathToSBProfile based on OS or asks user to select if it can not be found
	 */
	private void setPathToSBProfile()
	{
		//First, we guess the path
		
		//Variable to store guess for the path
		String guess="";
		
		//Guess Windows if the OS name contains "Win"
		if(System.getProperty("os.name").contains("Win"))
		{
			double osVer = 0;
			try
			{
				//Check OS version
				osVer = Double.parseDouble(System.getProperty("os.version"));
			}
			catch (NumberFormatException e)
			{}
			
			//Guess path based on OS version
			if(osVer < 6)
				guess="C:\\Documents and Settings\\All Users\\Application Data\\Sling Media\\SlingPlayer\\2.0\\SBProfile.xml";
			else
				guess="C:\\ProgramData\\Sling Media\\SlingPlayer\\2.0\\SBProfile.xml";
		}
		else //Otherwise guess it's running in WINE
		{
			File file;
			String homedir=System.getProperty("user.home");
			
			//Initial guess
			guess=homedir+"/.wine.slingplayer2/drive_c/users/Public/Application Data/Sling Media/SlingPlayer/2.0/SBProfile.xml";
			file = new File(guess);
			
			//If it doesn't exist, guess again
			if(!file.exists())
				guess=homedir+"/.wine/drive_c/users/Public/Application Data/Sling Media/SlingPlayer/2.0/SBProfile.xml";
		}
		
		
		
		//Check if SBProfile exists, prompt location if it does not
		File file = new File(guess);
		if(!file.exists())
		{
			CommonTasks.errorPopup("Failed to locate SBProfile.xml\nPlease select it manually.");
			Frame f = new Frame();        
			//decide from where to read the file
			FileDialog foBox = new FileDialog(f,"Save File", FileDialog.LOAD);
			foBox.setFile("SBProfile.xml");
			foBox.setVisible(true);
			if(foBox.getFile() != null)
			{
				pathToSBProfile.setText(foBox.getDirectory()+foBox.getFile());
			}
			else
			{
				CommonTasks.errorPopup("User canceled.\nProgram will exit.");
				System.exit(0);
			}
		}
		else
		{
			pathToSBProfile.setText(guess);
		}
	}
	
	/**
	 * Parses SBProfile.xml located at pathToSBProfile
	 * and stores the information as new SlingBox objects
	 */
	private void readSBProfile()
	{
		try
		{
			CommonTasks.messagePopup(
					"If you wish to import SlingBoxes from your Sling Account\n" +
					"please open SlingPlayer 2.0 and log into your account now.\n" +
					"\n" +
					"If you don't want to (or can't) log into your Sling Account\n" +
					"you may ignore this message and click OK.\n" +
					"\n" +
					"Click OK when you are ready to continue.", "Ready to import...");
			
			//prepare to read file
			File inFile = new File(pathToSBProfile.getText());
			BufferedReader in = new BufferedReader(new FileReader(inFile));
			String xmlData=""; //used to store file data
			String line = in.readLine(); // read in the first entire line from the file
			while(line != null) //finish reading file
			{
				xmlData+=line;
				line=in.readLine();
			}
			
			//make sure there's something to parse
			if(xmlData.contains("<Device ") && xmlData.contains("</DeviceDB"))
			{
				//Trim to DeviceDB entries only
				xmlData=xmlData.substring(xmlData.indexOf("<Device "), xmlData.indexOf("</DeviceDB"));
				//Trim first token
				xmlData=xmlData.substring(7);
				//split the remaining device entries into an array for easy parsing
				String[] deviceDb=xmlData.split("<Device ");
				
				for(int x=0; x < deviceDb.length; x++)
				{
					//temp string to store single slingbox entry for easier reference
					String sb = deviceDb[x];
					
					//trim out name
					String name=sb.substring(sb.indexOf(" name=\"")+7);
					name=name.substring(0, name.indexOf("\""));
					
					//trim out useaddress
					String useaddress=sb.substring(sb.indexOf("useaddress=\"")+12);
					useaddress=useaddress.substring(0, useaddress.indexOf("\""));
					
					//add a slingbox depending on connection method
					if(useaddress.equals("0"))
					{
						//trim out id
						String id=sb.substring(sb.indexOf(" id=\"")+5);
						id=id.substring(0, id.indexOf("\""));
						
						devices.add(new SlingBox(name,id));
					}
					else
					{
						//trim out address
						String address=sb.substring(sb.indexOf(" address=\"")+10);
						address=address.substring(0, address.indexOf("\""));
						
						//trim out port
						String port=sb.substring(sb.indexOf(" port=\"")+7);
						port=port.substring(0, port.indexOf("\""));
						
						devices.add(new SlingBox(name,address,port));
					}
					
					//add delete button for the slingbox added above
					JButton delete = new JButton("Delete");
					delete.addActionListener(this);
					deleteDevice.add(delete);
					
					//add edit button for the slingbox added above
					JButton edit = new JButton("Edit");
					edit.addActionListener(this);
					editDevice.add(edit);
				}
				
				//update list in display
				refreshDevices();
			}
			
			CommonTasks.messagePopup(
					"Please ensure you have loged out of your Sling Account\n" +
					"and then close SlingPlayer to prevent any problems.\n" +
					"\n" +
					"Click OK when you are finished.", "Import complete.");
		}
		catch(IOException e)
		{
			CommonTasks.errorPopup("Failed to read SBProfile.xml.\n\n" +
					"You may continue but some SlingBoxes may\n" +
					"not have been read from your Sling Directory.\n\n" +
					"Details: "+e.getLocalizedMessage());
		}
	}
	
	/**
	 * Re-builds the panel containing the list of SlingBoxes and their settings
	 */
	private void refreshDevices()
	{
		displayDevices.removeAll();
		
		//for padding
		JPanel pad = new JPanel();
		pad.setMaximumSize(new Dimension(0,0));
		displayDevices.add(pad);
		
		for(int x=0; x < devices.size(); x++)
		{	
			//create & format JPanel
			JPanel panel = new JPanel();
			panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
			panel.setPreferredSize(new Dimension(550,40));
			panel.setMaximumSize(panel.getPreferredSize());
			panel.setLayout(new BorderLayout());
			panel.add(new JPanel(), BorderLayout.WEST); //for padding
			
			//add SlingBox info
			if(devices.get(x).isUsingFinderID())
				panel.add(new JLabel("<html>Name: "+devices.get(x).getName()
						+"<br>Finder ID: "+devices.get(x).getId()),BorderLayout.CENTER);
			else
				panel.add(new JLabel("<html>Name: "+devices.get(x).getName()
						+"<br>Direct: "+devices.get(x).getAddress()+":"+devices.get(x).getPort()),BorderLayout.CENTER);
			
			
			JPanel east = new JPanel();
			east.add(deleteDevice.get(x)); //add delete button
			east.add(editDevice.get(x)); //add edit button
			panel.add(east, BorderLayout.EAST);
			
			displayDevices.add(panel);
		}
		
		displayDevices.add(new JPanel()); //needed to force refresh when removing panels
		this.validate();
	}
	
	/**
	 * Prompts user for data to create a new SlingBox entry
	 */
	public void newDevice()
	{
		SlingBox slingbox = SlingBoxEditor.createSlingbox();
		
		if(slingbox != null)
		{
			devices.add(slingbox);
			
			JButton delete = new JButton("Delete");
			delete.addActionListener(this);
			deleteDevice.add(delete);
			
			JButton edit = new JButton("Edit");
			edit.addActionListener(this);
			editDevice.add(edit);
			isSaved=false;
		}
	}
	
	/**
	 * Writes updated SBProfile.xml
	 */
	public void saveChanges()
	{
		//write changes to file
		try
		{
	        BufferedWriter out = new BufferedWriter(new FileWriter(pathToSBProfile.getText(), false));
	        out.write("<SBProfile><DeviceDB>");
	        //write each device
	        for(int x=0; x < devices.size(); x++)
	        {
	        	SlingBox device = devices.get(x);
	        	if(device.isUsingFinderID())
	        		out.write(
	        				"<Device dbid=\"\" slingboxId=\"\" product.id=\"\" countryId=\"1\" lastAccessTime=\"\" id=\""+device.getId()+"\" name=\""+device.getName()+"\" address=\"\" port=\"0\" useaddress=\"0\" last.address=\"\" last.port=\"0\" username=\"\" password=\"\" deleted=\"\" modified=\"\"/>"
	        				);
	        	else
	        		out.write(
	        				"<Device dbid=\"\" id=\"\" name=\""+device.getName()+"\" address=\""+device.getAddress()+"\" port=\""+device.getPort()+"\" useaddress=\"2\" last.address=\"\" last.port=\"0\" username=\"\" password=\"\" deleted=\"No\" modified=\"\"/>"
	        				);
	        }
	        out.write("</DeviceDB></SBProfile>");
	        out.close();
	        CommonTasks.messagePopup("Changes saved successfully.", "Done");
	    }
		catch (IOException e)
	    {
			CommonTasks.errorPopup("Error saving file:\n"+e.getMessage());
	    }
		isSaved=true;
	}
	
	
	/**
	 * @param x the index of the SlingBox object to remove
	 * Prompts for confirmation and deletes the SlingBox object at array index 'x'
	 */
	public void delete(int x)
	{
		//confirmation before delete
		if(JOptionPane.showConfirmDialog(null, "Are you sure you want to delete \""
				+devices.get(x).getName()+"\"?", "Confirm Delete", JOptionPane.YES_NO_OPTION,
				JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION)
		{
			devices.remove(x);
			deleteDevice.remove(x);
			editDevice.remove(x);
			isSaved=false;
		}
	}
	
	/**
	 * @param x the index of the SlingBox object to edit
	 * Opens the Edit SlingBox dialog to edit SlingBox at index 'x'
	 */
	public void edit(int x)
	{
		SlingBox slingbox = SlingBoxEditor.editSlingbox(devices.get(x));
		if(slingbox != null)
		{
			devices.set(x, slingbox);
			isSaved=false;
		}
	}
	
	/**
	 * @return the list of SlingBoxes
	 */
	public ArrayList<SlingBox> getDevices() {
		return devices;
	}

	/**
	 * @return true if all changes have been written to disk
	 */
	public boolean isSaved() {
		return isSaved;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowClosing(java.awt.event.WindowEvent)
	 */
	public void windowClosing(WindowEvent e)
	{
		if(!isSaved)
		{
			int saveChanges=JOptionPane.showConfirmDialog(null, 
					"Save changes before exit?", "Exiting...",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
			
			if(saveChanges == JOptionPane.YES_OPTION)
			{
				saveChanges();
			}
			else if(saveChanges == JOptionPane.NO_OPTION)
			{
			}
			else //cancel or closed question
			{
				return;
			}
		}

		System.exit(0);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowActivated(java.awt.event.WindowEvent)
	 */
	public void windowActivated(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowClosed(java.awt.event.WindowEvent)
	 */
	public void windowClosed(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowDeactivated(java.awt.event.WindowEvent)
	 */
	public void windowDeactivated(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowDeiconified(java.awt.event.WindowEvent)
	 */
	public void windowDeiconified(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowIconified(java.awt.event.WindowEvent)
	 */
	public void windowIconified(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowOpened(java.awt.event.WindowEvent)
	 */
	public void windowOpened(WindowEvent e) {}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run()
	{
		//disable parent frame to prevent confusion
		this.setEnabled(false);
		
		//if user clicked "Help/About" button
		if(lastAction.getSource().equals(about))
		{
			CommonTasks.messagePopup(
					"Created by Matthew Miller\n" +
					"\n" +
					"I am in no way associated with Sling Media.  This software is provided as-is with absolutely no warranty expressed or\n" +
					"implied.  While I have found it to work properly on my system, you use it AT YOUR OWN RISK.  I will not be held responsible\n" +
					"for anything that happens intentional or unintentional as a result of using this software.\n" +
					"\n" +
					"This program was created to help alleviate problems caused by Sling�s servers being down by providing an alternative means\n" +
					"of connecting.  Currently in SlingPlayer 2.0 you must use a Sling Account to store, edit, and use your Sling Directory which\n" +
					"means if the accounts server is unavailable your SlingBox becomes a paperweight or you are forced to downgrade to\n" +
					"SlingPlayer 1.5.  The purpose of this application is to provide a workaround for editing the SlingBox Directory without using\n" +
					"a Sling Account.\n" +
					"\n" +
					"This program is provided as-is, you may use it however you like.  You are free to make changes as you see fit.  My only request\n" +
					"is that I receive credit for my code should anyone modify, re-use, or re-distribute it."
					, "Help/About Editor for SBProfile.xml");
		}
		
		//if user clicked "New Device"
		if(lastAction.getSource().equals(newDevice))
		{
			newDevice();
		}
		
		//if user clicked "Save Changes"
		if(lastAction.getSource().equals(saveChanges))
		{
			saveChanges();
		}
		
		//if any of the "Delete" buttons were pressed
		if(lastAction.getActionCommand().equals("Delete"))
		{
			//call delete for corrisponding SlingBox
			delete(deleteDevice.indexOf(lastAction.getSource()));
		}
		
		//if any of the "Edit" buttons were pressed
		if(lastAction.getActionCommand().equals("Edit"))
		{
			//call edit for corrisponding SlingBox
			edit(editDevice.indexOf(lastAction.getSource()));
		}
		
		//refresh list
		refreshDevices();
		//re-enable main frame
		this.setEnabled(true);
	}
}

