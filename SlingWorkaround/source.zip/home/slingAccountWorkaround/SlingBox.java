//Matthew Miller
//August 10, 2010
//SlingBox.java
//Stores data about connecting to a SlingBox

package slingAccountWorkaround;

/**
 * @author Matthew Miller
 * Stores essential data for connecting to a SlingBox
 */
public class SlingBox {
	private String name;
	private String id;
	private String address;
	private String port;
	private boolean usingFinderID;
	
	/**
	 * @param name The name of the SlingBox
	 * @param id The Finder ID
	 * @param address The Direct Connect internet address
	 * @param port The Direct Connect port number
	 * @param useFinderID true is use Finder ID, false is Direct Connect
	 * 
	 * Create SlingBox manually
	 */
	public SlingBox(String name, String id, String address, String port, boolean useFinderID) {
		this.name = name;
		this.id = id;
		this.address = address;
		this.port = port;
		this.usingFinderID = useFinderID;
	}
	/**
	 * @param name The name of the SlingBox
	 * @param id The Finder ID
	 * Create SlingBox using FinderID
	 */
	public SlingBox(String name, String id) {
		this.name = name;
		this.id = id;
		this.address="";
		this.port="";
		this.usingFinderID=true;
	}
	/**
	 * @param name The name of the SlingBox
	 * @param address The internet address
	 * @param port The port
	 * Create SlingBox using Direct Connect
	 */
	public SlingBox(String name, String address, String port) {
		this.name = name;
		this.id="";
		this.address = address;
		this.port = port;
		this.usingFinderID=false;
	}
	/**
	 * @return the internet address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @return the Finder ID
	 */
	public String getId() {
		return id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}
	/**
	 * @return true if using Finder ID, false if using Direct Connect
	 */
	public boolean isUsingFinderID() {
		return usingFinderID;
	}

}
