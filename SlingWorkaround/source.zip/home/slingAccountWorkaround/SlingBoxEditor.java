//Matthew Miller
//August 12, 2010
//Updated August 19, 2010
//SlingBoxEditor.java
//
//To use for an applet:
//change "extends JFrame" to "extends JApplet"
//and rename "static void main(...)" "void init()" 

package slingAccountWorkaround;
import javax.swing.*;

import classesByMatt.CommonTasks;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;

/**
 * @author Matthew Miller
 * GUI for creating and modifying SlingBox objects
 */
@SuppressWarnings("serial")
public class SlingBoxEditor extends JFrame implements ActionListener
{
	//instantiate componants (JButton, JTextField, etc.)
	private JTextField name = new JTextField(25);
	private JRadioButton finderID = new JRadioButton("Finder ID");
		private JTextField id = new JTextField(27);
	private JRadioButton direct = new JRadioButton("Direct Connect");
		private JTextField address = new JTextField(15);
		private JTextField port = new JTextField(4);
	private JButton ok = new JButton("OK");
	private JButton cancel = new JButton("Cancel");
	private boolean commit=false;
	
	private static Object lock = new Object(); 

	
	/**
	 * Creates main GUI
	 */
	public SlingBoxEditor()
	{
		//set main parameters
		this.setSize(350,200);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		//Create JPanel(s) and add componants to panels
		JPanel panel1 = new JPanel();
			panel1.add(new JLabel("Name:"));
			panel1.add(name);

		JPanel panel2 = new JPanel();
			panel2.setLayout(new BorderLayout());
			panel2.add(finderID,BorderLayout.NORTH);
			JPanel idPanel = new JPanel();
				idPanel.add(new JLabel("ID:"));
				idPanel.add(id);
				id.setEnabled(false);
				panel2.add(idPanel,BorderLayout.CENTER);

		JPanel panel3 = new JPanel();
			panel3.setLayout(new BorderLayout());
			panel3.add(direct,BorderLayout.NORTH);
			JPanel directPanel = new JPanel();
				directPanel.add(new JLabel("Address:"));
				directPanel.add(address);
				address.setEnabled(false);
				directPanel.add(new JLabel(" Port:"));
				directPanel.add(port);
				port.setEnabled(false);
			panel3.add(directPanel,BorderLayout.CENTER);
			
		ButtonGroup method = new ButtonGroup();
			method.add(finderID);
			method.add(direct);
			
		JPanel main = new JPanel();
			main.setLayout(new BoxLayout(main,BoxLayout.Y_AXIS));
			main.add(panel1);
			main.add(panel2);
			main.add(panel3);
			
		JPanel buttons = new JPanel();
			buttons.add(cancel);
			buttons.add(ok);
			
		//Add panels to container
		@SuppressWarnings("unused")
		Container container = getContentPane();
		container.add(main, BorderLayout.CENTER);
		container.add(buttons, BorderLayout.SOUTH);
		
		//Add action listeners
		finderID.addActionListener(this);
		direct.addActionListener(this);
		ok.addActionListener(this);
		cancel.addActionListener(this);
		this.getRootPane().setDefaultButton(ok); //enter presses OK
	}
	
	/**
	 * @param args
	 * Used for debugging
	 */
	public static void main(String[] args)
	{
		createSlingbox();
		/*
		//Create GUI frame and set parameters
		SlingBoxEditor frame = new SlingBoxEditor();
		frame.setTitle("Edit SlingBox");
		frame.setSize(350,200);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);*/
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		//if radio button for Finder ID is clicked
		if(e.getSource().equals(finderID))
		{
			//Enable Finder ID text field
			id.setEnabled(true);
			//Disable Direct Connect text fields
			address.setEnabled(false);
			port.setEnabled(false);
		}
		
		//if radio button for Direct Connect is clicked
		if(e.getSource().equals(direct))
		{
			//disable Finder ID text field
			id.setEnabled(false);
			//Enable Direct Connect text fields
			address.setEnabled(true);
			port.setEnabled(true);
		}
		
		//if user cancels
		if(e.getSource().equals(cancel))
		{
			//close frame
			this.dispose();
			//continue program
			synchronized (lock) {  
                lock.notify(); 
            } 
		}
		
		//if user clicks OK
		if(e.getSource().equals(ok))
		{
			//validate data
			boolean error=false;
			
			//builds specific error details
			String detail="Invalid Field(s):\n";
			if(name.getText().isEmpty())
			{
				error=true;
				detail+="Name\n";
			}
			if(finderID.isSelected())
			{
				if(id.getText().isEmpty())
				{
					error=true;
					detail+="Finder ID";
				}
			}
			else if(direct.isSelected())
			{
				if(address.getText().isEmpty())
				{
					error=true;
					detail+="Address\n";
				}
				if(port.getText().isEmpty() || (!isNumeric(port.getText() )))
				{
					error=true;
					detail+="Port\n";
				}
			}
			else
			{
				error=true;
				detail+="Connection Method (Finder ID/Direct)\n";
			}
			
			//if fails validation, display error details
			if(error)
			{
				CommonTasks.errorPopup(detail);
			}
			else //if there is no error
			{
				//mark changes saved
				commit=true;
				//close frame
				this.dispose();
				//continue program
				synchronized (lock) {  
                    lock.notify(); 
                } 
			}
		}
	}
	
	/**
	 * @return New SlingBox object with user-specified settings
	 * Returns null if user canceled
	 */
	public static SlingBox createSlingbox()
	{
		SlingBoxEditor frame = new SlingBoxEditor();
		
		//set defaults
		frame.name.setText("My Slingbox");
		frame.port.setText("5001");
		
		//build frame details
		frame.setTitle("Add SlingBox");
		frame.setVisible(true);
		
		//wait for input
		synchronized(lock)
		{ 
            while (frame.isVisible()) 
            {
                try { 
                    lock.wait(); 
                } catch (InterruptedException e) {}
            } 
		}
		
		//if user pressed OK
		if(frame.commit)
		{
			if(frame.finderID.isSelected())
				return new SlingBox(frame.name.getText(),frame.id.getText());
			else
				return new SlingBox(frame.name.getText(),frame.address.getText(),frame.port.getText());
		}
		else //if user pressed Cancel
			return null;
	}
	
	/**
	 * @param slingbox object to be edited
	 * @return new SlingBox object with updated settings
	 * Returns null if user canceled
	 */
	public static SlingBox editSlingbox(SlingBox slingbox)
	{
		SlingBoxEditor frame = new SlingBoxEditor();

		//populate fields
		frame.name.setText(slingbox.getName());
		frame.id.setText(slingbox.getId());
		frame.address.setText(slingbox.getAddress());
		frame.port.setText(slingbox.getPort());
		
		//set radio button and fields correctly
		if(slingbox.isUsingFinderID())
		{
			frame.finderID.setSelected(true);
			frame.id.setEnabled(true);
			frame.address.setEnabled(false);
			frame.port.setEnabled(false);
		}
		else
		{
			frame.direct.setSelected(true);
			frame.id.setEnabled(false);
			frame.address.setEnabled(true);
			frame.port.setEnabled(true);
		}
		
		frame.setTitle("Edit SlingBox");
		frame.setVisible(true);
		
		synchronized(lock)
		{ 
           while (frame.isVisible()) 
            {
                try { 
                    lock.wait(); 
                } catch (InterruptedException e) {}
            } 
		}
		
		//if user pressed OK
		if(frame.commit)
		{
			if(frame.finderID.isSelected())
				return new SlingBox(frame.name.getText(),frame.id.getText());
			else
				return new SlingBox(frame.name.getText(),frame.address.getText(),frame.port.getText());
		}
		else //if user pressed Cancel
			return null;
	}
	
	/**
	 * @param value String to test
	 * @return true if string is an integer
	 */
	private boolean isNumeric(String value)
	{
		try
		{
			Integer.parseInt(value);
			return true;
		}
		catch(NumberFormatException e)
		{
			return false;
		}
	}
}

