//Matthew Miller
//March 29, 2008
//A bunch of commands I use frequently

package classesByMatt;

import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 * @author Matthew Miller
 * A bunch of commands I frequently use
 */
public class CommonTasks
{

	/**
	 * @param question
	 * @param title
	 * @return answer
	 */
	public static String askPopup(String question, String title)
	{
		return (String) JOptionPane.showInputDialog(null, question,title, JOptionPane.QUESTION_MESSAGE, null, null, "Type your answer here.");
	}
	
	/**
	 * @param question
	 * @param title
	 * @param defaultInput
	 * @return answer
	 */
	public static String askPopup(String question, String title, String defaultInput)
	{
		return (String) JOptionPane.showInputDialog(null, question,title, JOptionPane.QUESTION_MESSAGE, null, null, defaultInput);
	}

	/**
	 * @param question
	 * @param title
	 * @param font
	 * @return answer
	 */
	public static String askPopup(String question, String title, Font font)
	{
		Font currentFont = UIManager.getFont("OptionPane.messageFont");
		UIManager.put("OptionPane.messageFont",font);
		String answer=askPopup(question,title);
		UIManager.put("OptionPane.messageFont",currentFont);
		return answer;
	}

	/**
	 * @param question
	 * @param title
	 * @param font
	 * @return answer
	 */
	public static String askPopup(String question, String title, String defaultInput, Font font)
	{
		Font currentFont = UIManager.getFont("OptionPane.messageFont");
		UIManager.put("OptionPane.messageFont",font);
		String answer=askPopup(question,title,defaultInput);
		UIManager.put("OptionPane.messageFont",currentFont);
		return answer;
	}

	/**
	 * @param message
	 */
	public static void errorPopup(String message)
	{
		JOptionPane.showMessageDialog(null, message, "Oops...",JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * @param message
	 * @param font
	 */
	public static void errorPopup(String message, Font font)
	{
		Font currentFont = UIManager.getFont("OptionPane.messageFont");
		UIManager.put("OptionPane.messageFont",font);
		errorPopup(message);
		UIManager.put("OptionPane.messageFont",currentFont);
	}

	/**
	 * @param message
	 * @param title
	 */
	public static void warningPopup(String message, String title)
	{
		JOptionPane.showMessageDialog(null, message, title,JOptionPane.WARNING_MESSAGE);
	}

	/**
	 * @param message
	 * @param title
	 * @param font
	 */
	public static void warningPopup(String message, String title, Font font)
	{
		Font currentFont = UIManager.getFont("OptionPane.messageFont");
		UIManager.put("OptionPane.messageFont",font);
		warningPopup(message,title);
		UIManager.put("OptionPane.messageFont",currentFont);
	}
	
	/**
	 * @param message
	 * @param title
	 */
	public static void messagePopup(String message, String title)
	{
		JOptionPane.showMessageDialog(null, message, title,JOptionPane.PLAIN_MESSAGE);
	}

	/**
	 * @param message
	 * @param title
	 * @param font
	 */
	public static void messagePopup(String message, String title, Font font)
	{
		Font currentFont = UIManager.getFont("OptionPane.messageFont");
		UIManager.put("OptionPane.messageFont",font);
		messagePopup(message,title);
		UIManager.put("OptionPane.messageFont",currentFont);
	}

	/**
	 * sets Look and Feel to System
	 */
	public static void setSystemUI()
	{
		try 
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch (Exception e) {}
	}

	/**
	 * sets Look and Feel to Cross-Platform
	 */
	public static void setCrossPlatformUI()
	{
		try
		{
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		}
		catch (Exception e) {}
	}
	
	/**
	 * @param fontName
	 * @return font
	 */
	public static Font fontStyle(String fontName)
	{
		return new Font(fontName,Font.PLAIN,12);
	}
	
	/**
	 * @param format
	 * @return The formatted date/time
	 */
	public static String systemDateTime(String format)
	{
		return (new SimpleDateFormat(format).format(new Date()));
	}
	
	/**
	 * @param seconds
	 * @return The formatted time
	 */
	public static String systemTime24H(boolean seconds)
	{
		if(seconds)
			return (new SimpleDateFormat("HH:mm:ss").format(new Date()));
		else
			return (new SimpleDateFormat("HH:mm").format(new Date()));
	}
	
	/**
	 * @param seconds
	 * @return The formatted time
	 */
	public static String systemTime12H(boolean seconds)
	{
		if(seconds)
			return (new SimpleDateFormat("hh:mm:ss a").format(new Date()));
		else
			return (new SimpleDateFormat("hh:mm a").format(new Date()));
	}
	
	/**
	 * @return System time in HHmm format
	 */
	public static String systemTimeMilitaryFormat()
	{
		return (new SimpleDateFormat("HHmm").format(new Date()));
	}
	
	/**
	 * @param str
	 * @param length
	 * @return the string either cut to length or with spaces appended
	 * 
	 * If the string is longer than 3 characters it trims and puts "..." to indicate it was truncated.  If it's 3 or less characters it just truncates.
	 */
	public static String makeLength(String str,int length)
	{
		//trim to length
		if(str.length()>length)
		{
			if(length>3)
			{
				//neatly trim
				if(str.length()>length)
					str=str.substring(0, length-3) + "...";
			}
			else//just trim
				str=str.substring(0, length);
		}
		
		//fill with white space
		for(int x=str.length(); x<length; x++)
			str+=" ";
		
		return str;
	}
}
